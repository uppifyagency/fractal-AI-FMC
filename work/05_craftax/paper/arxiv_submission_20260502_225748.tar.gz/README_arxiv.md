# arXiv submission package — Chain-tier Compounding Amplification

## What this is

This tarball is the LaTeX source for a workshop-track paper on
zero-training Crafter / Craftax-Classic FMC results. Built from the
markdown master in `paper/draft.md` via `paper/md2tex.py` +
`paper/build_main_tex.py`.

## Files

- `main.tex` — the only LaTeX file you compile
- `references.bib` — bibliography (~25 entries, all verified)
- `figures/*.pdf` — 6 publication figures (vector PDF, 300 DPI)

## Compile

```bash
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

If pdflatex is not installed: install MacTeX (~4 GB) or BasicTeX (~80 MB):

```bash
brew install --cask mactex            # full
# or
brew install --cask basictex          # minimal; you'll need to install
                                       # extra packages on first compile
```

Or compile in the cloud:
- Overleaf: upload all files, choose "pdflatex" engine
- arXiv's own preview compiles automatically before submission

## Before submitting to arXiv

1. **Replace the author block** at the top of `main.tex`:
   - Currently: `\author[1]{Anonymous Author}` and
                `\affil[1]{Anonymous Affiliation \\\texttt{anonymous@example.org}}`
   - Replace with your real name, affiliation, ORCID, email.

2. **Verify abstract is at most 1920 characters** (arXiv limit).

3. **Submit at https://arxiv.org/submit**:
   - Category: cs.LG (primary), cs.AI (secondary)
   - License: arXiv default (non-exclusive distribution)
   - Comments field: "Workshop submission, 9 pages + 4 appendices,
     5 figures."

4. **Endorser**: if first arXiv submission, you need an endorser in
   cs.LG. Sergio Hernández-Cerezo or any prior arXiv-published author
   in this area can endorse.

5. **Cross-listing**: consider adding stat.ML or cs.NE depending on
   reviewer audience.

## Limitations to flag in the comments field

The peer review (`paper/peer_review_self.md`) lists open weaknesses:
- 18/30 seed completion (target 30, hit budget cap)
- L1 ablation single-seed (others n=30)
- Cross-benchmark Crafter-original is preliminary (3-seed exp17 vs
  3-seed v4 smoke; full study is companion work)
- Figure 4 is a programmatic schematic, not Nano-Banana-rendered

These are honestly stated in the paper itself. Address them as the
work progresses if you upgrade to a conference-track v2.

## Data + code release

The full repository (including the FMC implementation, autoresearch
loop, ablation runner, statistical tests) is at:
- (your repo URL here)

Specifically:
- `work/05_craftax/autoresearch/fmc_mutable.py` (12 KB single-file FMC)
- `work/05_craftax/autoresearch/results.tsv` (24-experiment log)
- `work/05_craftax/autoresearch/results/*.json` (per-experiment raw_runs)
- `work/05_crafter_original_port/fmc_crafter.py` (Crafter port)
